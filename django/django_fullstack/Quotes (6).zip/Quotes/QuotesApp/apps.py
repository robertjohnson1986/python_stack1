from django.apps import AppConfig


class QuotesappConfig(AppConfig):
    name = 'QuotesApp'
