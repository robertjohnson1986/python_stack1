from django.apps import AppConfig


class E2BlackappConfig(AppConfig):
    name = 'E2BlackApp'
